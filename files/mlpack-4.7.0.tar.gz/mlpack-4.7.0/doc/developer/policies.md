# Template policies

mlpack has a number of common template policy patterns that are used in various
algorithms.

 * [The ElemType policy](elemtype.md)
 * [The DistanceType policy](distances.md)
 * [The KernelType policy](kernels.md)
 * [The TreeType policy](trees.md)
