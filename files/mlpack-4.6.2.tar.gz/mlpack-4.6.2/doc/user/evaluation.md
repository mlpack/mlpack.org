<object data="../img/pipeline-top-5.svg" type="image/svg+xml" id="pipeline-top">
</object>

# Evaluation

Once a model is trained, mlpack contains a number of utilities for testing the
model.

 * [Cross-validation](cv.md): k-fold cross-validation tools for any mlpack
   algorithm
 * [Hyperparameter tuning](hpt.md): generic hyperparameter tuner to find
   good hyperparameters for any mlpack algorithm
