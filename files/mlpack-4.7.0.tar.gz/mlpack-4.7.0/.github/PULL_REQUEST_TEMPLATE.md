
### Pull Request Template

When opening a PR for mlpack, please explain _in your own words_ the changes you want to apply.
Make sure that you have read [CONTRIBUTING.md](https://github.com/mlpack/mlpack/blob/master/CONTRIBUTING.md), including part about LLM policy, before opening a PR.
