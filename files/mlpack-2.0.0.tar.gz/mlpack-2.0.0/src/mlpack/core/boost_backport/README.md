The files in this directory are taken from Boost 1.56.0 in order to backport
serialization support for unordered_map.  Therefore these files are licensed
under the Boost Software License.
